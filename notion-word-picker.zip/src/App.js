import NotionWordPicker from './NotionWordPicker';

export default function App() {
  return <NotionWordPicker />;
}